package com.nikhilgu.covidmonitor;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.content.Intent;
import android.content.Context;
import android.app.AlertDialog;
import android.widget.EditText;
import android.content.DialogInterface;


public class DailyTrackerActivity extends Activity {

    Button saveBtn;
    Button openBtn;
    Button returnBtn;
    EditText text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_tracker);

        // Variables are declared
        text = findViewById(R.id.text);
        openBtn = findViewById(R.id.open_button);
        saveBtn = findViewById(R.id.save_button);
        returnBtn = findViewById(R.id.return_button);

        // Notes Activity Page ----> Question Activity Page
        returnBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(DailyTrackerActivity.this, QuestionActivity.class));
            }
        });
    }

    public void buttonAction(View v) {
        final EditText fileName = new EditText(this);
        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setView(fileName);

        // User input the # of symptoms to save function
        if ( R.id.save_button == v.getId()) {
            ad.setMessage("Input Date (MM-DD-YYYY):");

            // Save entry
            ad.setPositiveButton("Save",new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    try {
                        FileOutputStream fout=openFileOutput(fileName.getText().toString()+".txt",Context.MODE_PRIVATE); ;
                        fout.write(text.getText().toString().getBytes());
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Error Occurred: "+e,Toast.LENGTH_LONG).show();
                    }
                }
            });

            // If user wants to cancel entry
            ad.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            ad.show();
        }

        //  User can open previous symptoms from past entries
        if(v.getId()==R.id.open_button) {
            ad.setMessage("Check Daily Symptoms (MM-DD-YYYY):");

            ad.setPositiveButton("Open",new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    int open;
                    text.setText("");

                    try {
                        FileInputStream fin = openFileInput(fileName.getText().toString()+".txt");

                        while ((open = fin.read()) != -1)
                        {
                            text.setText((text.getText().toString() + Character.toString((char) open)));
                        }
                    }catch (Exception e) {
                        Toast.makeText(getApplicationContext(), "Error Occurred: "+e,Toast.LENGTH_LONG).show();
                    }
                }
            });

            // If user wants to cancel entry
            ad.setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            ad.show();
        }

    }

}
