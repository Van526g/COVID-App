package com.nikhilgu.covidmonitor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class InfoMenuActivity extends AppCompatActivity {
    private Button symptom_list_Btn;
    private Button preventionBtn;
    private Button testingBtn;
    private Button globalBtn;
    private Button returnBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_menu);
        this.getSupportActionBar().hide();

        returnBtn = findViewById(R.id.return_button);
        symptom_list_Btn = findViewById(R.id.symptom_list_button);
        preventionBtn = findViewById(R.id.prevention_button);
        testingBtn = findViewById(R.id.testing_button);
        globalBtn = findViewById(R.id.global_data_button);

        // Info Menu Activity Page ----> Symptom List Activity Page
        symptom_list_Btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoMenuActivity.this, SymptomsListActivity.class));
            }
        });

        // Prevention Activity Page ----> Symptom List Activity Page
        preventionBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoMenuActivity.this, PreventionActivity.class));
            }
        });

        // Info Menu Activity Page ----> Testing Activity Page
        testingBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoMenuActivity.this, TestingActivity.class));
            }
        });

        // Info Menu Activity Page ----> Info Activity Page
        globalBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoMenuActivity.this, InfoActivity.class));
            }
        });

        // Info Menu Activity Page ----> Question Activity Page
        returnBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoMenuActivity.this, QuestionActivity.class));
            }
        });
    }
}

