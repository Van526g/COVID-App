package com.nikhilgu.covidmonitor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;
public class DailyTrackerActivity extends AppCompatActivity {
    private Button returnBtn;
    private CalendarView calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        this.getSupportActionBar().hide();

        returnBtn = findViewById(R.id.return_button);
        calendar = findViewById(R.id.calendarView2);




        // Daily Tracker Activity Page ----> Question Activity Page
        returnBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(DailyTrackerActivity.this, QuestionActivity.class));
                //finish();
            }
        });
    }
}