package com.nikhilgu.covidmonitor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PreventionActivity extends AppCompatActivity {
    private Button returnBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prevention);
        this.getSupportActionBar().hide();

        returnBtn = findViewById(R.id.return_info_menu_button);

        // Prevention Activity Page ----> Info Menu Activity Page
        returnBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(PreventionActivity.this, InfoMenuActivity.class));
            }
        });
    }
}