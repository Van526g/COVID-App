package com.nikhilgu.covidmonitor;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
public class ResultActivity extends AppCompatActivity {
    private Button returnBtn;
    private Button postBtn;
    private TextView resultLbl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        this.getSupportActionBar().hide();

        returnBtn = findViewById(R.id.return_button);
        postBtn = findViewById(R.id.post_button);
        resultLbl = findViewById(R.id.resultLabel);


        // Result Activity Page ----> Question Activity Page
        returnBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(ResultActivity.this, QuestionActivity.class));
                //finish();
            }
        });
    }
}
